}

/* ------------------------------------------------------------------------ */

#if defined(_WIN32) && !defined(GLEW_EGL) && !defined(GLEW_OSMESA)

static void wglewInfo ()
{
